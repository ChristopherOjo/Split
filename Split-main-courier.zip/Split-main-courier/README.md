# Split

The Split App is a mobile app that enables people to lower the cost of their bills by sharing their account online.

In order to use this repository you must:
 - download XMAPP onto your C: drive and start Apache and SQL
 - click on the admin button for sql and create a database called loginregister
 - create a table called users and add 5 columns
 - The 5 columns should be id, fullname, username, password, email
 - click A_I for id
 - select TEXT for fullname and password, and VARCHAR for username and email
 - select UNIQUE for username and email under the primary buttom and save the table
 - adjust the IPv4 address in the Login.java and Signup.java file to enable to SQL file to work
 - drag and drop the LoginRegister into the XAMPP htdocs folder (can be found by clicking Explorer on the XAMPP Control Panel)

After these steps are taken the Login/User shall work flawlessly.
Reference Images:
![image](https://user-images.githubusercontent.com/74805861/117572085-49d64580-b09f-11eb-9048-ee5ce44b3dde.png)
![image](https://user-images.githubusercontent.com/74805861/117572105-61adc980-b09f-11eb-8230-0d855561895b.png)
![image](https://user-images.githubusercontent.com/74805861/117572152-928dfe80-b09f-11eb-84e5-36c65f00a250.png)
![image](https://user-images.githubusercontent.com/74805861/117572187-b3eeea80-b09f-11eb-865b-16f84ac921ce.png)
![image](https://user-images.githubusercontent.com/74805861/117572298-498a7a00-b0a0-11eb-9a8e-ecfc2d279a64.png)

For more help reference this youtube video: https://youtu.be/X8oD4q3XtQQ?t=58
