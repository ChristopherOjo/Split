
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		app_concept
	 *	@date 		1620504702897
	 *	@title 		Design
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

	public class loginpage extends AppCompatActivity {

	
	private View _bg__page_2_ek2;
	private TextView log_in;
	private TextView log_in_ek1;
	private View home_indicator_ek1;
	private TextView __plit_ek1;
	private TextView sign_into_your_account;
	private View border_ek1;
	private ImageView cap_ek1;
	private View capacity_ek1;
	private ImageView wifi_ek1;
	private ImageView cellular_connection_ek1;
	private TextView time_ek1;
	private View rectangle_2;
	private TextView username;
	private ImageView vector;
	private ImageView vector_ek1;
	private ImageView vector_ek2;
	private ImageView vector_ek3;
	private TextView password;
	private TextView forgot_password__click_here_to_reset_;
	private View rectangle_5;
	private View rectangle_6;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);


		log_in = (TextView) findViewById(R.id.log_in);
		log_in_ek1 = (TextView) findViewById(R.id.log_in_ek1);

		__plit_ek1 = (TextView) findViewById(R.id.__plit_ek1);
		sign_into_your_account = (TextView) findViewById(R.id.sign_into_your_account);

		rectangle_2 = (View) findViewById(R.id.rectangle_2);
		username = (TextView) findViewById(R.id.username);
		vector = (ImageView) findViewById(R.id.vector);
		vector_ek1 = (ImageView) findViewById(R.id.vector_ek1);
		vector_ek2 = (ImageView) findViewById(R.id.vector_ek2);
		vector_ek3 = (ImageView) findViewById(R.id.vector_ek3);
		password = (TextView) findViewById(R.id.password);
		forgot_password__click_here_to_reset_ = (TextView) findViewById(R.id.forgot_password__click_here_to_reset_);
		rectangle_5 = (View) findViewById(R.id.rectangle_5);
		rectangle_6 = (View) findViewById(R.id.rectangle_6);
	
		
		//custom code goes here

	}

	public void cn1(View v){
		startActivity(new Intent(loginpage.this, testca.class));
	}
}
	
	