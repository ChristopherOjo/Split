
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		app_concept
	 *	@date 		1620504702897
	 *	@title 		Design
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

	public class page_3_activity extends AppCompatActivity {

	
	private View _bg__page_3_ek2;
	private View border_ek2;
	private ImageView cap_ek2;
	private View capacity_ek2;
	private ImageView wifi_ek2;
	private ImageView cellular_connection_ek2;
	private TextView time_ek2;
	private View rectangle_1;
	private TextView apple_one;
	private View rectangle_1_ek1;
	private TextView disney_;
	private View rectangle_1_ek2;
	private TextView crave;
	private View rectangle_1_ek3;
	private TextView other;
	private View rectangle_1_ek4;
	private ImageView default_boyo_1;
	private View rectangle_ek1;
	private TextView canada;
	private ImageView shape_copy;
	private ImageView chevron_right;
	private View _rectangle_1_ek5;
	private TextView canada_ek1;
	private View rectangle_ek2;
	private ImageView icon;
	private ImageView netflix_1;
	private TextView netflix;
	private TextView new_york_city;
	private View rectangle_1_ek6;
	private TextView canada_ek2;
	private View rectangle_ek3;
	private TextView spotify;
	private TextView canada_ek3;
	private ImageView spotify_logo_png_7078_1;
	private View rectangle_1_ek7;
	private TextView new_york_city_ek1;
	private View rectangle_ek4;
	private TextView youtube;
	private TextView canada_ek4;
	private ImageView youtube_1;
	private ImageView shape;
	private ImageView vector_ek4;
	private ImageView vector_ek5;
	private ImageView vector_ek6;
	private ImageView vector_ek7;
	private View rectangle_2_ek1;
	private TextView new_york_city_ek2;
	private View rectangle_ek5;
	private ImageView icon_ek1;
	private TextView crunchyroll_mega;
	private TextView canada_ek5;
	private ImageView crunchyroll_1;
	private ImageView vector_ek8;
	private ImageView vector_ek9;
	private ImageView vector_ek10;
	private ImageView vector_ek11;
	private View rectangle_ek6;
	private View home_indicator_ek2;
	private View rectangle_ek7;
	private ImageView vector__stroke_;
	private ImageView vector__stroke__ek1;
	private View rectangle_ek8;
	private ImageView vector_ek12;
	private View rectangle_ek9;
	private ImageView vector__stroke__ek2;
	private View rectangle_ek10;
	private ImageView vector__stroke__ek3;
	private ImageView vector__stroke__ek4;
	private ImageView vector__stroke__ek5;
	private ImageView logo_1;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.testc);

		

		rectangle_1 = (View) findViewById(R.id.rectangle_1);
		apple_one = (TextView) findViewById(R.id.apple_one);
		rectangle_1_ek1 = (View) findViewById(R.id.rectangle_1_ek1);
		disney_ = (TextView) findViewById(R.id.disney_);
		rectangle_1_ek2 = (View) findViewById(R.id.rectangle_1_ek2);
		crave = (TextView) findViewById(R.id.crave);
		rectangle_1_ek3 = (View) findViewById(R.id.rectangle_1_ek3);
		other = (TextView) findViewById(R.id.other);
		rectangle_1_ek4 = (View) findViewById(R.id.rectangle_1_ek4);
		default_boyo_1 = (ImageView) findViewById(R.id.default_boyo_1);
		rectangle_ek1 = (View) findViewById(R.id.rectangle_ek1);
		canada = (TextView) findViewById(R.id.canada);
		shape_copy = (ImageView) findViewById(R.id.shape_copy);
		chevron_right = (ImageView) findViewById(R.id.chevron_right);


		vector__stroke__ek5 = (ImageView) findViewById(R.id.vector__stroke__ek5);
		logo_1 = (ImageView) findViewById(R.id.logo_1);
	
		
		_rectangle_1_ek5.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), page_4_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	