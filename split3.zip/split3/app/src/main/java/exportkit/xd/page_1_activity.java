
	 
	/*
     *	This content is generated from the API File Info.
     *	(Alt+Shift+Ctrl+I).
     *
     *	@desc
     *	@file 		app_concept
     *	@date 		1620504702897
     *	@title 		Design
     *	@author
     *	@keywords
     *	@generator 	Export Kit v1.3.figma
     *
     */


    package exportkit.xd;

    import android.app.Activity;
    import android.content.Intent;
    import android.os.Bundle;


    import android.view.View;
    import android.widget.ImageView;
    import android.widget.TextView;

    import androidx.appcompat.app.AppCompatActivity;

    public class page_1_activity extends AppCompatActivity {


        private View _bg__page_1_ek2;
        private ImageView transparent_logo_1;
        private TextView next;
        private View home_indicator;
        private TextView __plit;
        private TextView split_the_bill_towards_your_next_subscription_payment_with_people_in_the_community_;
        private View oval;
        private View oval_ek1;
        private View rectangle;
        private View border;
        private ImageView cap;
        private View capacity;
        private ImageView wifi;
        private ImageView cellular_connection;
        private TextView time;

        @Override
        public void onCreate(Bundle savedInstanceState) {

            super.onCreate(savedInstanceState);
            setContentView(R.layout.page_1);


            _bg__page_1_ek2 = (View) findViewById(R.id._bg__page_1_ek2);
            transparent_logo_1 = (ImageView) findViewById(R.id.transparent_logo_1);

            __plit = (TextView) findViewById(R.id.__plit);
            split_the_bill_towards_your_next_subscription_payment_with_people_in_the_community_ = (TextView) findViewById(R.id.split_the_bill_towards_your_next_subscription_payment_with_people_in_the_community_);


            time = (TextView) findViewById(R.id.time);


            //custom code goes here

        }

        public void cm1(View v) {
            startActivity(new Intent(page_1_activity.this, loginpage.class));
        }
    }
	
	