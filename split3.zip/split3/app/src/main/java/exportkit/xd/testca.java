package exportkit.xd;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class testca extends AppCompatActivity {
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        int cards, datanum = 0;
        if (datanum == 1) {
            String content1 = null;
            String content2 = null;
            String content3 = null;
            String content4 = null;
            String content5 = null;
            String content6 = null;
            String content7 = null;
            String content8 = null;
            String content9 = null;
            String content10 = null;
            View view1 = findViewById(R.id.linearLayout1);
            view1.setVisibility(View.VISIBLE);
            setContentsOfTextView(R.id.card1, content1);
            setContentsOfTextView(R.id.card2, content2);
        } else if (datanum == 2) {
            String content1 = null;
            String content2 = null;
            String content3 = null;
            String content4 = null;
            String content5 = null;
            String content6 = null;
            String content7 = null;
            String content8 = null;
            String content9 = null;
            String content10 = null;
            View view1 = findViewById(R.id.linearLayout1);
            view1.setVisibility(View.VISIBLE);
            View view2 = findViewById(R.id.linearLayout2);
            view2.setVisibility(View.VISIBLE);
            setContentsOfTextView(R.id.card1, content1);
            setContentsOfTextView(R.id.card2, content2);

            setContentsOfTextView(R.id.card3, content3);
            setContentsOfTextView(R.id.card4, content4);
        } else if (datanum == 3) {
            String content1 = null;
            String content2 = null;
            String content3 = null;
            String content4 = null;
            String content5 = null;
            String content6 = null;
            String content7 = null;
            String content8 = null;
            String content9 = null;
            String content10 = null;
            View view1 = findViewById(R.id.linearLayout1);
            view1.setVisibility(View.VISIBLE);
            View view2 = findViewById(R.id.linearLayout2);
            view2.setVisibility(View.VISIBLE);
            View view3 = findViewById(R.id.linearLayout3);
            view3.setVisibility(View.VISIBLE);
            setContentsOfTextView(R.id.card1, content1);
            setContentsOfTextView(R.id.card2, content2);

            setContentsOfTextView(R.id.card3, content3);
            setContentsOfTextView(R.id.card4, content4);

            setContentsOfTextView(R.id.card5, content5);
            setContentsOfTextView(R.id.card6, content6);
        } else if (datanum == 4) {
            String content1 = null;
            String content2 = null;
            String content3 = null;
            String content4 = null;
            String content5 = null;
            String content6 = null;
            String content7 = null;
            String content8 = null;
            String content9 = null;
            String content10 = null;
            View view1 = findViewById(R.id.linearLayout1);
            view1.setVisibility(View.VISIBLE);
            View view2 = findViewById(R.id.linearLayout2);
            view2.setVisibility(View.VISIBLE);
            View view3 = findViewById(R.id.linearLayout3);
            view3.setVisibility(View.VISIBLE);
            View view4 = findViewById(R.id.linearLayout4);
            view4.setVisibility(View.VISIBLE);
            setContentsOfTextView(R.id.card1, content1);
            setContentsOfTextView(R.id.card2, content2);

            setContentsOfTextView(R.id.card3, content3);
            setContentsOfTextView(R.id.card4, content4);

            setContentsOfTextView(R.id.card5, content5);
            setContentsOfTextView(R.id.card6, content6);

            setContentsOfTextView(R.id.card7, content7);
            setContentsOfTextView(R.id.card8, content8);
        } else if (datanum == 5) {
            String content1 = null;
            String content2 = null;
            String content3 = null;
            String content4 = null;
            String content5 = null;
            String content6 = null;
            String content7 = null;
            String content8 = null;
            String content9 = null;
            String content10 = null;
            View view1 = findViewById(R.id.linearLayout1);
            view1.setVisibility(View.VISIBLE);
            View view2 = findViewById(R.id.linearLayout2);
            view2.setVisibility(View.VISIBLE);
            View view3 = findViewById(R.id.linearLayout3);
            view3.setVisibility(View.VISIBLE);
            View view4 = findViewById(R.id.linearLayout4);
            view4.setVisibility(View.VISIBLE);
            View view5 = findViewById(R.id.linearLayout5);
            view5.setVisibility(View.VISIBLE);
            setContentsOfTextView(R.id.card1, content1);
            setContentsOfTextView(R.id.card2, content2);

            setContentsOfTextView(R.id.card3, content3);
            setContentsOfTextView(R.id.card4, content4);

            setContentsOfTextView(R.id.card5, content5);
            setContentsOfTextView(R.id.card6, content6);

            setContentsOfTextView(R.id.card7, content7);
            setContentsOfTextView(R.id.card8, content8);

            setContentsOfTextView(R.id.card9, content9);
            setContentsOfTextView(R.id.card10, content10);
        }
        setContentView(R.layout.testc);


    }

    private void setContentsOfTextView(int id, String newContents) {
        View view = findViewById(id);
        TextView textView = (TextView) view;
        textView.setText(newContents);
    }

    public void cn3 (View v){

    }
}
