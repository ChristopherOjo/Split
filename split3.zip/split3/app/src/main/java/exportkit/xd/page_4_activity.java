
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		app_concept
	 *	@date 		1620504702897
	 *	@title 		Design
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.content.Intent;
import android.widget.TextView;

public class page_4_activity extends Activity {

	
	private View _bg__page_4_ek2;
	private View rectangle_3;
	private View rectangle_4;
	private ImageView _back_arrow_1;
	private View home_indicator_ek3;
	private View border_ek3;
	private ImageView cap_ek3;
	private View capacity_ek3;
	private ImageView wifi_ek3;
	private ImageView cellular_connection_ek3;
	private TextView time_ek3;
	private ImageView netflix_2;
	private TextView enter_plan;
	private TextView netflix_ek1;
	private TextView canada_ek6;
	private View rectangle_ek11;
	private ImageView people_1;
	private View rectangle_ek12;
	private ImageView payment_1;
	private TextView _3_4;
	private TextView current___6_33;
	private TextView netflix_is_a_subscription_based_streaming_service_that_allows_our_members_to_watch_tv_shows_and_movies_without_commercials_on_an_internet_connected_device__you_can____;
	private TextView more;
	private View rectangle_1_ek8;
	private ImageView yellow_bg_man;
	private View rectangle_1_ek9;
	private ImageView female_icon;
	private View rectangle_1_ek10;
	private ImageView man_icon;
	private View rectangle_1_ek11;
	private TextView __;
	private ImageView vector_ek13;
	private ImageView vector_ek14;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.netflixtemp);

		

		rectangle_3 = (View) findViewById(R.id.rectangle_3);
		rectangle_4 = (View) findViewById(R.id.rectangle_4);
		_back_arrow_1 = (ImageView) findViewById(R.id._back_arrow_1);

		netflix_2 = (ImageView) findViewById(R.id.netflix_2);

		netflix_ek1 = (TextView) findViewById(R.id.nameprof);
		canada_ek6 = (TextView) findViewById(R.id.canada_ek6);
		rectangle_ek11 = (View) findViewById(R.id.rectangle_ek11);
		people_1 = (ImageView) findViewById(R.id.people_1);
		rectangle_ek12 = (View) findViewById(R.id.rectangle_ek12);
		payment_1 = (ImageView) findViewById(R.id.payment_1);
		_3_4 = (TextView) findViewById(R.id._3_4);
		current___6_33 = (TextView) findViewById(R.id.current);
		netflix_is_a_subscription_based_streaming_service_that_allows_our_members_to_watch_tv_shows_and_movies_without_commercials_on_an_internet_connected_device__you_can____ = (TextView) findViewById(R.id.netflix_is_a_subscription_based_streaming_service_that_allows_our_members_to_watch_tv_shows_and_movies_without_commercials_on_an_internet_connected_device__you_can____);

		yellow_bg_man = (ImageView) findViewById(R.id.yellow_bg_man);

		female_icon = (ImageView) findViewById(R.id.female_icon);
		rectangle_1_ek10 = (View) findViewById(R.id.rectangle_1_ek10);
		man_icon = (ImageView) findViewById(R.id.man_icon);

		__ = (TextView) findViewById(R.id.__);
		vector_ek13 = (ImageView) findViewById(R.id.vector_ek13);

	
		
		_back_arrow_1.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), testca.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}

	public void cmm2(View v){
		startActivity(new Intent(page_4_activity.this, testca.class));
	}
}
	
	